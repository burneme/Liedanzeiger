#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pygame
import sys
import threading
import time
import os
import re
import requests

def rgb(value):
    value = value.lstrip('#')
    if len(value) == 6:
        return tuple(int(value[i:i+2], 16) for i in (0, 2 ,4))
    return (0, 0, 0)

class displayThread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.nmr = 000
        self.part = 0
        self.Schrift = ""
        self.Lied = ""
        self.Strophe = ""
        self.Mkoff = False;
        self.config = {}

        os.system("vcgencmd display_power 1")
        self.disoff = None   # cas vypnuti displeje
        self.pwr_is_off = False # displej je vypnuty
        self.offlimit = 25*60 # limit pro vypnuti displeje v sekundach, doporucuji cca 30 minut kvuli moznemu zobrazeni modre obrazovky
        self.totlimit = 90*60 # limit necinnosti v sekundach - 1.5 hodiny
        self.last_change = time.time()
    
        self.set_scheme(1)
     
        self.changed = True
        pygame.display.init()
        pygame.font.init()
        pygame.mouse.set_visible(False)

    def set_scheme(self, color):
        if color == 0:
            # zlute pozadi, tmavy text + oranzova sloka
            self.config = {
                "background" : rgb("#ffffef"),
                "number" : rgb("111111"),
                "part" : rgb("cc3300"),
            }

        elif color == 1:
            # zlute pozadi, cerveny text, seda sloka
            self.config = {
                "background" : rgb("000000"), # zluta 
                "number" : rgb("ffffff"),
                "part" : rgb("ff4400"),
            }

#    def get_number(self):
#        return "%03d%02d" % (self.nmr, self.part)

    def replaceZero(self):
        St = self.Schrift[3::]
        Li = self.Schrift[0:3]
#        print("St=",St)
        self.Schrift = ""
        try:
          if int(Li) == 0:
            self.Mkoff = True
            # =nur Dunkel
          else:
            self.Mkoff = False  
        except: 
            self.Mkoff = False
            
        regexPattern = "^0+(?!$)"
        self.Lied = re.sub(regexPattern,"",Li)
        self.Strophe = re.sub(regexPattern, "", St)       
        if self.Strophe == "0":
            self.Strophe = ""
        self.changed = True

    def set_number(self, value, change_name = True):
        try:
            requests.get(f"http://192.168.4.2/display_"+value, timeout=1)
        except:
            pass
        if value=="inv":
           self.set_scheme(1)
           print("scheme=invers")
           self.changed = True
           return
        elif value=="nor":
           self.set_scheme(0)
           print("scheme=normal")
           self.changed = True
           return
        elif value=="off":
           os.system("vcgencmd display_power 0")
           self.pwr_is_off = True
           return;
        elif value=="onn":
           os.system("vcgencmd display_power 1")
           self.pwr_is_off = False
           return;

        self.Schrift = value
#        print("rec:",value,"eived")
        self.replaceZero()
        self.last_change = time.time()  
        return True

    def conf(self, k):
        if k in self.config:
            return self.config[k]
        return (0, 0, 0)

    def run(self):
        # maximal mögliche Auflösung
        modes = pygame.display.list_modes()
        mode = max(modes)
        screen = pygame.display.set_mode(mode)
        s_width, s_height = mode
        clock = pygame.time.Clock()

        # nicht mit ESC-Taste beendet
        self.done = False
        self.Mkoff = False

        # definice pisem
        font = pygame.font.Font("fonts/DroidSerif/DroidSerif-Bold.ttf", 800)
        font_large = pygame.font.Font("fonts/DroidSerif/DroidSerif-Bold.ttf", 900) #1100
        font2_small = pygame.font.Font("fonts/DroidSerif/DroidSerif-Regular.ttf", 450) #400
        font2_large = pygame.font.Font("fonts/DroidSerif/DroidSerif-Regular.ttf", 550) #500
        font3 = pygame.font.Font("fonts/DroidSerif/DroidSerif-Italic.ttf", 180)

        self.Schrift = ""
        self.Lied = ""
        self.Strophe = ""
                                                       

        while not self.done:
            if not self.changed:    
                for event in pygame.event.get():
                  clock.tick(9)
                  if (not self.changed):  
                    if event.type == pygame.QUIT:
                        self.done = True
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            self.done = True
                        elif (len(self.Schrift) < 10 and not event.key in [pygame.K_KP_ENTER, pygame.K_RETURN]):
                           self.Schrift += event.unicode
                           self.last_change = time.time()
                        else:
                           self.replaceZero()
            if self.changed:
                if  not self.Mkoff:  # anzeige ist per Befehl aus?
                    self.disoff = time.time();
                    if self.pwr_is_off:
                        self.pwr_is_off = False
                        os.system("vcgencmd display_power 1")

                    screen.fill(self.conf("background"))
                    if  len(self.Strophe) == 0:  #not self.part: # nur Liednummer
                        text = font_large.render("%s" % self.Lied, True, self.conf("number"))
                        # Block Transfer to the screen
                        screen.blit(text, ((s_width - text.get_width()) // 2, (s_height + 50 - text.get_height()) // 2  ))
                    else:
                        if len(self.Strophe) == 1: 
                            font2 = font2_large
                        else:
                            font2 = font2_small
                        text = font.render("%s" % self.Lied, True, self.conf("number"))
                        text2 = font2.render("%s" % self.Strophe, True, self.conf("part"))

                        part_corr = font.get_descent() - font2.get_descent()
                        
                        bottom = s_height
                        
                        if  len(self.Strophe) <= 2:
                            corr1 = -text2.get_width() // 2
                            corr2 = text.get_width() // 2
                            screen.blit (text, (corr1 + (s_width - text.get_width()) // 2, bottom - text.get_height()))
                            screen.blit (text2, (corr2 + (s_width - text2.get_width()) // 2, bottom - text2.get_height() + part_corr))
                        else:
                            screen.blit (text, ((s_width - text.get_width()) // 2, bottom - 215 - text.get_height()))
                            screen.blit (text2, ((s_width - text2.get_width()) // 2, bottom + 75 - text2.get_height()))

                else: # displej je vyply
                    if not self.disoff:
                        self.disoff = time.time()
                    screen.fill(rgb("#000000")) # schwarz

                    
            pygame.display.flip() # update all
            self.changed = False

# nach 15min dunkel, nach weiteren 15min Standby
            if self.Mkoff: # Display unabhängig von der Änerung ausschalten
                if not self.pwr_is_off and (time.time() - self.disoff) > self.offlimit:
                    os.system("vcgencmd display_power 0")
                    self.pwr_is_off = True
            elif (time.time() - self.disoff) > self.offlimit:
                    self.Mkoff = True  # schalte Bildschirm dunkel
                    self.disoff = time.time()
                    self.changed = True      
                      
            if not self.pwr_is_off and time.time() - self.last_change > self.totlimit:
                os.system("vcgencmd display_power 0")
                self.pwr_is_off = True
            clock.tick(1)
# hier is der Ausgang:        

        if self.pwr_is_off:
            self.pwr_is_off = False
            os.system("vcgencmd display_power 1")

        pygame.quit()
        print("Display EXIT")
